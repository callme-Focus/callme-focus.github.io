"use strict";
chrome.action.onClicked.addListener(tab=>{
  const panel=new URL(chrome.runtime.getURL("panel.html"));
  if(/^https?:\/\//.test(tab.url||""))panel.hash=new URLSearchParams({result:tab.url});
  chrome.tabs.create({url:panel.href});
});
