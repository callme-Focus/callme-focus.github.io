"use strict";
const FrontVision=(()=>{
  let loading=null;
  const size=224,mean=[.48145466,.4578275,.40821073],std=[.26862954,.26130258,.27577711];
  const labels={front:"正面单品",back:"背面",person:"模特或人台",detail:"细节或辅助图",other:"其他展示方式"};
  async function engine(){
    if(!loading)loading=(async()=>{
      const base=new URL("vision/",location.href).href;
      ort.env.wasm.numThreads=1;ort.env.wasm.proxy=false;ort.env.wasm.wasmPaths=base;
      const response=await fetch(base+"prompts.json");if(!response.ok)throw Error("缺少本地视觉提示表");
      const prompts=await response.json(),width=Math.max(...prompts.map(item=>item.ids.length));
      const ids=new BigInt64Array(prompts.length*width).fill(49407n),mask=new BigInt64Array(ids.length);
      prompts.forEach((prompt,index)=>{const offset=index*width;ids.set(prompt.ids.map(BigInt),offset);mask.fill(1n,offset,offset+prompt.ids.length)});
      return {model:await ort.InferenceSession.create(base+"tiny.onnx",{executionProviders:["wasm"]}),prompts,
        ids:new ort.Tensor("int64",ids,[prompts.length,width]),mask:new ort.Tensor("int64",mask,[prompts.length,width])};
    })().catch(error=>{loading=null;throw error});
    return loading;
  }
  function inputPixels(bitmap,box=null){
    const canvas=new OffscreenCanvas(size,size),ctx=canvas.getContext("2d",{willReadFrequently:true});
    ctx.fillStyle="#fff";ctx.fillRect(0,0,size,size);
    const region=box||[0,0,bitmap.width,bitmap.height];
    const factor=size/Math.max(region[2],region[3]),width=region[2]*factor,height=region[3]*factor;
    ctx.imageSmoothingQuality="high";ctx.drawImage(bitmap,...region,(size-width)/2,(size-height)/2,width,height);
    const rgba=ctx.getImageData(0,0,size,size).data,data=new Float32Array(3*size*size);
    for(let index=0;index<size*size;index++)for(let channel=0;channel<3;channel++)data[channel*size*size+index]=(rgba[index*4+channel]/255-mean[channel])/std[channel];
    return data;
  }
  function subjectBox(bitmap){
    const scale=128/Math.max(bitmap.width,bitmap.height),width=Math.max(2,Math.round(bitmap.width*scale)),height=Math.max(2,Math.round(bitmap.height*scale));
    const ctx=new OffscreenCanvas(width,height).getContext("2d",{willReadFrequently:true});ctx.fillStyle="#fff";ctx.fillRect(0,0,width,height);ctx.drawImage(bitmap,0,0,width,height);
    const rgba=ctx.getImageData(0,0,width,height).data,corners=[0,width-1,width*(height-1),width*height-1],bg=[0,1,2].map(channel=>corners.map(pos=>rgba[pos*4+channel]).sort((left,right)=>left-right)[1]);
    if(corners.some(pos=>bg.some((value,channel)=>Math.abs(rgba[pos*4+channel]-value)>30)))return null;
    let left=width,right=-1,top=height,bottom=-1,count=0;
    for(let row=0;row<height;row++)for(let col=0;col<width;col++){
      const pos=4*(row*width+col);if(bg.some((value,channel)=>Math.abs(rgba[pos+channel]-value)>40)){
        left=Math.min(left,col);right=Math.max(right,col);top=Math.min(top,row);bottom=Math.max(bottom,row);count++;
      }
    }
    if(count<.025*width*height||(right-left)*(bottom-top)>.85*width*height)return null;
    const pad=.1*Math.max(right-left,bottom-top);left=Math.max(0,left-pad);top=Math.max(0,top-pad);right=Math.min(width,right+pad+1);bottom=Math.min(height,bottom+pad+1);
    return [left*bitmap.width/width,top*bitmap.height/height,(right-left)*bitmap.width/width,(bottom-top)*bitmap.height/height];
  }
  async function classifyView(pixels){
    const {model,prompts,ids,mask}=await engine();
    const input=new ort.Tensor("float32",pixels,[1,3,size,size]);
    const results=await model.run({input_ids:ids,attention_mask:mask,pixel_values:input},["logits_per_image"]);
    try{
      const logits=results.logits_per_image.data;
      if(logits.length!==prompts.length||!Array.from(logits).every(Number.isFinite))throw Error("模型输出异常");
      const groups={};prompts.forEach((prompt,index)=>(groups[prompt.group]??=[]).push(logits[index]));
      const ranked=Object.entries(groups).map(([group,values])=>[group,values.reduce((sum,value)=>sum+value,0)/values.length]).sort((first,second)=>second[1]-first[1]);
      const [winner,score]=ranked[0],gap=score-ranked[1][1];
      const offTarget=ranked.filter(([key])=>!["front","back"].includes(key))[0][1];
      return {winner,gap,garmentMargin:score-offTarget};
    }finally{input.dispose();Object.values(results).forEach(output=>output.dispose())}
  }
  async function classifyPixels(bytes){
    const bitmap=await createImageBitmap(new Blob([bytes]));
    let full,subject;try{
      if(Math.min(bitmap.width,bitmap.height)<80)throw Error("图片过小");
      full=inputPixels(bitmap);const box=subjectBox(bitmap);if(box)subject=inputPixels(bitmap,box);
    }finally{bitmap.close()}
    const first=await classifyView(full),second=subject?await classifyView(subject):null;
    const group=first.winner,views=second?[first,second]:[first];
    const agreement=views.every(view=>view.winner===group);
    const confident=agreement&&(views.every(view=>view.gap>=1)||
      Boolean(second)&&["front","back"].includes(group)&&views.every(view=>view.garmentMargin>=1));
    const kind=!confident?"review":group==="front"?"keep":"skip";
    return {kind,group,gap:Number(Math.min(...views.map(view=>view.gap)).toFixed(2)),views:views.map(view=>view.winner).join("/"),
      reason:"本机 AI："+(kind==="review"?"证据不足，不自动打包":labels[group])+(second&&agreement?"（全图与主体视图一致）":""),model:"TinyCLIP-8M/int8"};
  }
  return {classifyPixels};
})();

function variantKey(raw){
  const url=new URL(raw);
  if(/^\/cdn\/shop\/(?:files|products)\//.test(url.pathname)||url.hostname==="cdn.shopify.com"&&/^\/s\/files\//.test(url.pathname))url.searchParams.delete("width");
  return url.href;
}
function preferPixels(row){return Number(new URL(row.url).searchParams.get("width"))||0}
async function applyVision(rows,{canRead,stop,notify}){
  const groups=new Map(),blocked=new Set();
  for(const row of rows){
    if(row.kind==="review"&&/\.gif(?:$|[?#])/i.test(row.url)){row.kind="skip";row.reason="动态 GIF 不属于正面静态商品图"}
    if(row.kind==="skip")continue;
    const key=variantKey(row.url);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row);
  }
  let inferred=0,success=0,errors=0;
  for(const siblings of groups.values()){
    stop();
    siblings.sort((left,right)=>preferPixels(right)-preferPixels(left));
    const leader=siblings.find(row=>row.kind==="keep")||siblings[0];
    if(leader.kind==="review"){
      if(inferred>=64){leader.reason="本批 AI 已达到 64 张上限，未自动收录";continue}
      if(!await canRead(leader.url)){blocked.add(new URL(leader.url).origin);leader.reason="待授权图片来源，AI 尚未运行";continue}
      inferred++;notify("本机 AI 正在看第 "+inferred+" 张："+leader.product);
      try{
        const {bytes}=await imageBytes(leader.url);
        const result=await FrontVision.classifyPixels(bytes);stop();leader.kind=result.kind;leader.reason=result.reason;
        leader.model=result.model;leader.visual_class=result.group;leader.visual_margin=result.gap;leader.visual_views=result.views;success++;
      }catch(error){stop();errors++;leader.reason="AI 未完成："+error.message}
    }
    for(const sibling of siblings)if(sibling!==leader){sibling.kind="skip";sibling.reason="同一商品图的其他尺寸，保留较大候选"}
  }
  return {blocked:[...blocked],inferred,success,errors};
}
