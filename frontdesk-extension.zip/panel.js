"use strict";
const el=id=>document.getElementById(id),delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let candidates=[],rows=[],working=false,stopped=false,ownedTab=null,inspected=null,missingOrigins=[];
const log=message=>{el("log").textContent+=message+"\n"};
const chosen=()=>candidates.filter((_,index)=>el("link-"+index)?.checked);
function controls(){
  el("discover").disabled=working;el("sites").disabled=working;el("keyword").disabled=working;el("sample").disabled=working;
  el("scan").disabled=working||!chosen().length;el("stop").disabled=!working;el("csv").disabled=working||!rows.length;el("export").disabled=working||!rows.some(row=>row.kind==="keep");
  el("visionGrant").disabled=working;for(const input of el("links").querySelectorAll("input"))input.disabled=working;
}
function begin(){working=true;stopped=false;controls()}
function end(){working=false;controls()}
function parsed(raw){const url=new URL(raw);if(!/^https?:$/.test(url.protocol)||url.username||url.password)throw Error("仅支持普通 HTTP(S) 页面");return url}
function grant(urls){return chrome.permissions.request({origins:[...new Set(urls.map(raw=>{const url=parsed(raw);return url.protocol+"//"+url.hostname+"/*"}))]})}
function checked(){if(stopped)throw Error("已停止任务")}
function clearVision(){missingOrigins=[];el("visionStatus").textContent="";el("visionGrant").hidden=true}
async function runVision(){
  const report=await applyVision(rows,{
    canRead:url=>{const target=parsed(url);return chrome.permissions.contains({origins:[target.protocol+"//"+target.hostname+"/*"]})},
    stop:checked,notify:text=>{el("visionStatus").textContent=text}
  });
  missingOrigins=report.blocked;el("visionGrant").hidden=!missingOrigins.length;
  const message="本轮 AI 看图完成 "+report.success+" 张，异常 "+report.errors+" 张。"+(missingOrigins.length?"以下图片域名需要一次授权："+missingOrigins.map(origin=>new URL(origin).hostname).join("、"):"");
  el("visionStatus").textContent=message;log(message);
}
async function inspect(url,method,query){
  checked();const tab=await chrome.tabs.create({url:"about:blank",active:false});ownedTab=tab.id;
  try{
    await chrome.tabs.update(tab.id,{url});let ready=false;
    for(let step=0;step<90;step++){checked();await delay(300);const info=await chrome.tabs.get(tab.id);if(info.url&&info.url!=="about:blank"&&(info.status==="complete"||step>=14)){ready=true;break}}
    if(!ready)throw Error("页面加载超时");
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:["collector.js"]});
    const [reply]=await chrome.scripting.executeScript({target:{tabId:tab.id},args:[method,query],func:async(method,query)=>{
      const text=(document.title+" "+document.body?.innerText?.slice(0,500)).toLowerCase();
      if(/captcha|verify (?:you are|you're) human|verify (?:that )?you are|人机验证|安全验证|access denied|just a moment|sign in to continue/.test(text)||/\/(?:login|signin|challenge)(?:[/?#]|$)/i.test(location.pathname))return {error:"页面要求登录或验证，已跳过"};
      let data=[],last=-1,stable=0;
      for(let attempt=0;attempt<10;attempt++){
        data=method==="catalog"?readCatalog(document,location.href,query):readProduct(document,location.href);
        stable=data.length===last?stable+1:0;last=data.length;
        if(data.length&&stable>=2)break;
        await new Promise(resolve=>setTimeout(resolve,300));
      }
      return {data};
    }});
    checked();if(!reply?.result||reply.result.error)throw Error(reply?.result?.error||"无法读取页面");return reply.result.data;
  }finally{await chrome.tabs.remove(tab.id).catch(()=>{});if(ownedTab===tab.id)ownedTab=null}
}
function listLinks(){
  const list=document.createElement("ul");
  candidates.forEach((item,index)=>{const line=document.createElement("li"),label=document.createElement("label"),box=document.createElement("input");box.type="checkbox";box.id="link-"+index;box.checked=true;box.style.width="auto";box.onchange=controls;
    label.append(box," "+new URL(item.url).hostname+" · "+item.title);line.append(label);line.title=item.url;list.append(line)});
  el("links").replaceChildren(list);controls();
}
function summary(){
  const counts=["keep","review","skip"].map(kind=>rows.filter(row=>row.kind===kind).length);
  el("summary").textContent="已收录 "+counts[0]+" · 待核对 "+counts[1]+" · 已跳过 "+counts[2]+"。待核对项不下载。";
  const list=document.createElement("ul");
  rows.forEach(row=>{const line=document.createElement("li"),anchor=document.createElement("a");anchor.href=row.source;anchor.target="_blank";anchor.rel="noopener noreferrer";anchor.textContent=row.product;
    const inspect=document.createElement("button");inspect.textContent="看原图";inspect.className="outline";inspect.onclick=()=>{
      if(working)return;inspected=row;el("photo").src=row.url;el("name").textContent=row.product;el("evidence").textContent=row.reason+" · "+(row.caption||row.filename);el("accept").hidden=row.kind!=="review";el("reject").hidden=row.kind==="skip";el("proof").showModal()
    };
    line.append(anchor," · "+row.reason+" ",inspect);list.append(line)});
  el("records").replaceChildren(list);
}
const current=new URLSearchParams(location.hash.slice(1)).get("result");
if(current){try{el("sites").value=parsed(current).href}catch{}history.replaceState(null,"",location.pathname)}
el("sample").onclick=()=>{const raw=prompt("粘贴正面采集室作品首页地址（或本机样店地址）",current||"");if(!raw)return;try{const origin=parsed(raw).origin;el("sites").value=["arc","field"].map(shop=>origin+"/shop/"+shop+"/search.html?q={q}").join("\n");el("status").textContent="已填入两家样店。私人预览需先登录；若图片需要登录，请使用网页演示下载。"}catch{el("status").textContent="请输入有效的 HTTP(S) 首页地址。"}};
el("discover").onclick=async()=>{
  const query=el("keyword").value.trim(),templates=el("sites").value.split(/\r?\n/).map(line=>line.trim()).filter(Boolean);
  if(!query||!templates.length||templates.length>3){el("status").textContent="请输入关键词，以及 1 至 3 个搜索入口。";return}
  try{
    const urls=templates.map(template=>parsed(template.replaceAll("{q}",encodeURIComponent(query))).href);
    begin();clearVision();candidates=[];rows=[];el("records").replaceChildren();el("summary").textContent="等待采集。";el("packed").textContent="";el("log").textContent="";listLinks();
    if(!await grant(urls))throw Error("未授权读取所选搜索站点");
    const seen=new Map();
    for(const url of urls){checked();const target=new URL(url);if(/\/products\/[^/]+\/?$/.test(target.pathname)){seen.set(url,{url,title:decodeURIComponent(target.pathname.split("/").filter(Boolean).at(-1))});log("直接复采指定商品："+url);continue}el("status").textContent="正在读取 "+target.hostname+"…";
      try{const links=await inspect(url,"catalog",query);log("搜索页 "+url+"：发现 "+links.length+" 条候选链接");for(const link of links){if(!seen.has(link.url)&&seen.size<24)seen.set(link.url,link)}}catch(error){log(url+" · "+error.message);checked()}
    }
    candidates=[...seen.values()];listLinks();el("status").textContent="待访问 "+candidates.length+" 个商品页。请确认范围，再开始采集。"+(candidates.length?"":" 未发现可用链接，请检查任务日志或更换入口。");
  }catch(error){el("status").textContent=error.message}finally{end()}
};
el("scan").onclick=async()=>{
  const selected=chosen();if(!selected.length)return;
  const collected=[];let failures=0;
  try{begin();if(!await grant(selected.map(item=>item.url)))throw Error("未授权读取商品站点");
    clearVision();rows=[];el("packed").textContent="";summary();
    for(const [index,link] of selected.entries()){
      checked();el("status").textContent="采集中 "+(index+1)+" / "+selected.length+" · "+link.title;
      try{const images=await inspect(link.url,"product","");collected.push(...images);log(link.url+" · "+images.length+" 张候选图")}catch(error){failures++;log(link.url+" · "+error.message);checked()}
      await delay(450);
    }
    rows=decide(collected);await runVision();
    el("status").textContent="本次商品页处理结束，读取失败 "+failures+" 页。";
  }catch(error){if(!rows.length&&collected.length)rows=decide(collected);el("status").textContent=error.message}finally{summary();end()}
};
el("visionGrant").onclick=async()=>{
  try{begin();if(!await grant(missingOrigins))throw Error("未授权的图片不会上传或收录。");await runVision()}
  catch(error){el("visionStatus").textContent=error.message}finally{summary();end()}
};
el("stop").onclick=()=>{stopped=true;if(ownedTab!==null)chrome.tabs.remove(ownedTab).catch(()=>{});el("status").textContent="正在停止；已读取的商品保留。"};
el("export").onclick=async()=>{
  try{begin();el("stop").disabled=true;
    if(!await grant(rows.filter(row=>row.kind==="keep").map(row=>row.url)))throw Error("未授权读取图片域名；仍可导出来源清单。");
    const result=await exportPack(rows,text=>el("packed").textContent=text);el("packed").textContent="已生成 ZIP："+result.saved+" 张原图，"+result.failed+" 张失败；失败原因见 sources.csv。";
  }catch(error){el("packed").textContent=error.message}finally{end()}
};
el("csv").onclick=()=>downloadBlob(new Blob([manifestCSV(rows)],{type:"text/csv;charset=utf-8"}),"frontdesk-sources.csv");
el("dismiss").onclick=()=>el("proof").close();
for(const [id,accept] of [["accept",true],["reject",false]])el(id).onclick=()=>{
  if(!inspected||working)return;const warning=markReviewed(rows,inspected,accept);el("proof").close();el("packed").textContent=warning||"本次任务的复核结果已更新。";summary();controls()
};
window.addEventListener("pagehide",()=>{if(ownedTab!==null)chrome.tabs.remove(ownedTab).catch(()=>{})});
